package com.CheckYourUnderstanding.Task2.bo.auth;


public class LogoutResponse {

    private String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}

