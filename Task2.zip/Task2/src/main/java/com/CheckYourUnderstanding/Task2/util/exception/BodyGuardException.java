package com.CheckYourUnderstanding.Task2.util.exception;

public class BodyGuardException extends RuntimeException{
    public BodyGuardException(String str){
        super(str);
    }
}
