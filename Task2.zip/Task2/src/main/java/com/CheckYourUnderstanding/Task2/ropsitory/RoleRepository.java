package com.CheckYourUnderstanding.Task2.ropsitory;

import com.CheckYourUnderstanding.Task2.entity.RoleEntity;
import com.CheckYourUnderstanding.Task2.util.enums.Roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoleRepository extends JpaRepository<RoleEntity, Long> {

    RoleEntity findByTitle(Roles title);
}

