package com.CheckYourUnderstanding.Task2.bo;

public class CreateFarewellRequest {

    private String name;

    public String getName() {
        return name;
    }
}