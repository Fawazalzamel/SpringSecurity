package com.CheckYourUnderstanding.Task2.util.enums;

public enum Roles {

    USER,ADMIN
}
