package com.CheckYourUnderstanding.Task2.bo.user;

public class UpdateUserStatusRequest {

    private String status;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
